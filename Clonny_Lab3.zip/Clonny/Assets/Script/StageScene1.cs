﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageScene1 : MonoBehaviour
{
    //dinh nghia trang thai
    enum SceneStage
    {
        PLAY,RUNNING,DEATH
    }
    public static bool isPlay = false;
    public BirdMovement player;
    private SceneStage stage;
    //dinh nghia ham thay doi trang thai
    void ChangeState(SceneStage st) {
        switch (st)
        {
            case SceneStage.PLAY:
                Time.timeScale = 0;
                GetComponent<SpriteRenderer>().enabled = true;
                break;
            case SceneStage.RUNNING:
                Time.timeScale = 1;
                GetComponent<SpriteRenderer>().enabled = false;
                break;
            case SceneStage.DEATH:
                Time.timeScale = 0;
                GetComponent<SpriteRenderer>().enabled = true;
                break;   
        }
        this.stage = st;
    }
    void Start()
    {
        //khoi dau chay luon
        if(!isPlay)
            ChangeState(SceneStage.PLAY);
            isPlay = true;
            
    }
    void Update()
    {
        //neu chua chay
        if(Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)
        && this.stage!=SceneStage.RUNNING)
        {
            ChangeState(SceneStage.RUNNING);
        }

        //neu chim chet
        if(player.dead && this.stage != SceneStage.DEATH)
        {
            ChangeState(SceneStage.DEATH);
        }
        if(stage == SceneStage.DEATH)
        {
            //load level moi
            if(Input.GetKeyDown(KeyCode.Space)|| Input.GetMouseButtonDown(0)
            && this.stage != SceneStage.RUNNING)
            {
                Time.timeScale = 1;
                Application.LoadLevel(Application.loadedLevel);
            }
        }
    }
}
