﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pipe : MonoBehaviour
{
    public float speed;
    public int numGB = 6;
    private float pipeMax;
    private float pipeMin;
    private float khoangCachPipe;
    void Start()
    {
        //pipeMin, pipeMax chon ngau nhien
        this.pipeMin = -1.5f;
        this.pipeMax = -1f;
        //toc do di chuyen cua pipe
        this.speed = 0.5f;
        //khoang cach giua 2 pipe
        khoangCachPipe = 1.4f;
        //random chieu cao cua ong o lan dau tien
        Vector3 pos = transform.position;
        pos.y = Random.Range(pipeMin,pipeMax);
        transform.position = pos;
    }

    void Update()
    {
        //di chuyen
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }
    //ham detect chuong ngai vat
    void OnTriggerEnter2D(Collider other) {
       if(other.name=="BGLooper")
       {
           Vector3 pos = this.transform.position;
           pos.x += khoangCachPipe * numGB;
           pos.y += Random.Range(pipeMin,pipeMax);
           transform.position = pos;
       }
    }
}
