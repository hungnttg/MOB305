﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateTile : MonoBehaviour
{
   public float khoangCachGanNhatTuNhanVat;
   public GameObject DiaHinh;
   public float ChieuRongDiaHinh;
   public Transform player;

    void Start() {
       GenerateDiaHinh(1);
   }
   void GenerateDiaHinh(int n) {
       int i = 0;
       while (i<n)
       {
            Instantiate(DiaHinh,transform.position,Quaternion.identity);
            i++;
            transform.position += ChieuRongDiaHinh*Vector3.right;//huong phat trien cua dia hinh
       }
   }
    void FixedUpdate() {
       if(Vector3.Distance(player.position,transform.position)<=khoangCachGanNhatTuNhanVat)
       {
           GenerateDiaHinh(1);
       }
   }

}
