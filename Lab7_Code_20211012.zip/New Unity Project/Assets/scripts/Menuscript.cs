﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menuscript : MonoBehaviour
{
   public void loadScene()
   {
       Application.LoadLevel("SampleScene");//~ startActivity
   }
    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
