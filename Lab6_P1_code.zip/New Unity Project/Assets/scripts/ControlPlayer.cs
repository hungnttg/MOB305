﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlPlayer : MonoBehaviour
{
    public GameObject hieuUng,hieuUng1;
    public static bool isGameOver = false;
    public float speedX, speedY;
    private Animator player;//nhan vat
    int score = 0;
    public Text txtDiem;
    void Start()
    {
        txtDiem = GameObject.Find("txtDiem").GetComponent<Text>();//find by view id
        player = GetComponent<Animator>();//findByViewId
        isGameOver = false;//dang choi game
        Time.timeScale = 1;//ty le thoi gian bang thoi gian thuc
    }
    void Update()
    {
        if(!isGameOver)
        {
            if(Input.GetKey(KeyCode.LeftArrow))//sang trai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.left * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x >0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                    );
                }
            }
            else if(Input.GetKey(KeyCode.RightArrow))//sang phai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.right * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x <0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                       
                    );
                }
            }
            else if(Input.GetKey(KeyCode.Space))//nhay cao
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                //if(gameObject.tag == "Brick")
                //{
                    gameObject.GetComponent<Rigidbody2D>().velocity
                = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,
                speedY);
                //}
                
            }
            else
            {
                //thiet lap trang thai
                player.SetBool("isRunning",false);
                player.SetBool("isIdle",true);
            }
           
        }
    }
    private void OnCollisionEnter2D(Collision2D other) {
        if(other.gameObject.tag == "Coin")
        {
            score +=1;
            Destroy(other.gameObject);
            txtDiem.text = "Score: "+score.ToString();
            //goi hieu ung
            GameObject gob = Instantiate(hieuUng,gameObject.transform.position,Quaternion.identity);
            Destroy(gob,3);
        }
        if(other.gameObject.tag == "CNV")
        {
            score -=2;
            Destroy(other.gameObject);
            txtDiem.text = "Score: "+score.ToString();
            //goi hieu ung
            GameObject gob = Instantiate(hieuUng1,gameObject.transform.position,Quaternion.identity);
            Destroy(gob,2);
            if(score <=0)
            {
                Application.LoadLevel("Menu");
            }
        }
    }
}
