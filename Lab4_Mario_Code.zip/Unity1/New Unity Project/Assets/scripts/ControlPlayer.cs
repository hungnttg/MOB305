﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlPlayer : MonoBehaviour
{
    public static bool isGameOver = false;
    public float speedX, speedY;
    private Animator player;//nhan vat
    void Start()
    {
        player = GetComponent<Animator>();//findByViewId
        isGameOver = false;//dang choi game
        Time.timeScale = 1;//ty le thoi gian bang thoi gian thuc
    }
    void Update()
    {
        if(!isGameOver)
        {
            if(Input.GetKey(KeyCode.LeftArrow))//sang trai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.left * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x >0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                    );
                }
            }
            else if(Input.GetKey(KeyCode.RightArrow))//sang phai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.right * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x <0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                       
                    );
                }
            }
            else if(Input.GetKey(KeyCode.Space))//nhay cao
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                //if(gameObject.tag == "Brick")
                //{
                    gameObject.GetComponent<Rigidbody2D>().velocity
                = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,
                speedY);
                //}
                
            }
            else
            {
                //thiet lap trang thai
                player.SetBool("isRunning",false);
                player.SetBool("isIdle",true);
            }
           
        }
    }
}
