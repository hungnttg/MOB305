﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cnv2 : MonoBehaviour
{
    private Rigidbody2D e;//khai bao doi tuong trong code
    public bool checkDay;//bien kiem tra day
    void Start(){
        e = GetComponent<Rigidbody2D>();//findByViewId
    }
    void Update(){
        float moveY = 0f;//dau tien o vi tri so 0
        if(checkDay){//neu la day, di chuyen theo chieu am 1 doan 5
            moveY = -5f;
        }
        else{//neu la dinh thi di chuyen theo chieu duong 1 doan la 5
            moveY = 5f;
        }
        e.velocity = new Vector2(0, transform.localScale.y)*moveY;//van toc di chuyen
    }
    void OnCollisionEnter2D(Collision2D other) {//ham detech va cham
        if(other.gameObject.tag=="Day"){
            checkDay=false;
        }
        if(other.gameObject.tag=="Dinh"){
            checkDay=true;
        }
    }
}
