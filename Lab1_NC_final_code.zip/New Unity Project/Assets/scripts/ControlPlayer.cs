﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class ControlPlayer : MonoBehaviour
{
    public GameObject hieuUng,hieuUng1;
    public static bool isGameOver = false;
    public float speedX, speedY;
    private Animator player;//nhan vat
    int score = 0;
    public Text txtDiem;
    private IEnumerator idle;
    Button btnUp, btnLeft, btnRight;
    bool isBtnLeftClick=false;
    bool isBtnRightClick=false;
    bool isBtnUpClick=false;
    //start dinh nghia interface goi trang thai false sau 5s
    IEnumerator upFalse()
    {
        yield return new WaitForSeconds(5);
        isBtnUpClick=false;
        Debug.Log ("isBtnUpClick=false;");
    }
    IEnumerator rightFalse()
    {
        yield return new WaitForSeconds(5);
        isBtnRightClick=false;
        Debug.Log ("isBtnRightClick=false;");
    }
    IEnumerator leftFalse()
    {
        yield return new WaitForSeconds(5);
        isBtnLeftClick=false;
        Debug.Log ("isBtnLeftClick=false;");
    }
    //end dinh nghia interface goi trang thai false sau 5s
    //start dinh nghia su kien onclick
    void btnRightOnClick()
    {
        isBtnRightClick=true;
        Debug.Log ("You have clicked the button! Right");
        StartCoroutine(rightFalse());
    }
    void btnLeftOnClick()
    {
        isBtnLeftClick=true;
        Debug.Log ("You have clicked the button! Left");
        StartCoroutine(leftFalse());
    }
    void btnUpOnClick()
    {
        isBtnUpClick=true;
        Debug.Log ("You have clicked the button! Up");
        StartCoroutine(upFalse());
    }
    //end dinh nghia su kien onclick
    void Start()
    {
        //anh xa cac button
        btnRight = GameObject.Find("btnRight").GetComponent<Button>();//find by view id
        btnLeft = GameObject.Find("btnLeft").GetComponent<Button>();//find by view id
        btnUp = GameObject.Find("btnUp").GetComponent<Button>();//find by view id
        //detect su kien
        btnUp.onClick.AddListener(btnUpOnClick);
        btnRight.onClick.AddListener(btnRightOnClick);
        btnLeft.onClick.AddListener(btnLeftOnClick);

        mybody = GetComponent<Rigidbody2D>();
        txtDiem = GameObject.Find("txtDiem").GetComponent<Text>();//find by view id
        player = GetComponent<Animator>();//findByViewId
        isGameOver = false;//dang choi game
        Time.timeScale = 1;//ty le thoi gian bang thoi gian thuc
    }
    private Rigidbody2D mybody;
    public void moveLeft()
    {
                //di chuyen muot ma can them truc y
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                // khia bao 2 gia tri
                float forceX = 0f;
                float forceY = 0f;
                // nhan gia toc hien tai cua nhan vat
                float velo = Mathf.Abs(mybody.velocity.x);
                // nhan hanh dong tu ban phim
                        forceX = -155f;                
                    // hanh dong xaoy mat
                    Vector2 scale = transform.localScale;
                    scale.x = -1f;
                    transform.localScale = scale;    
                // cap nhat thong tin vi tri
                mybody.AddForce(new Vector2(forceX,forceY)); 
                
                
    }
    public void moveRight()
    {
                //di chuyen muot ma can them truc y
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                // khia bao 2 gia tri
                float forceX = 0f;
                float forceY = 0f;
                // nhan gia toc hien tai cua nhan vat
                float velo = Mathf.Abs(mybody.velocity.x);
                // nhan hanh dong tu ban phim
                        forceX = 155f;
                // hanh dong xaoy mat
                    Vector2 scale = transform.localScale;
                    scale.x = 1f;
                    transform.localScale = scale;    
                // cap nhat thong tin vi tri
                mybody.AddForce(new Vector2(forceX,forceY));
    }
    public void moveUp()
    {
                //di chuyen muot ma can them truc y
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                //if(gameObject.tag == "Brick")
                //{
                    gameObject.GetComponent<Rigidbody2D>().velocity
                = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,
                speedY);
                //}
        
    }
    
    void Update()
    {
        if(!isGameOver)
        {
            if(Input.GetKey(KeyCode.LeftArrow))//sang trai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.left * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x >0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                    );
                }
            }
            else if(Input.GetKey(KeyCode.RightArrow))//sang phai
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                 //di chuyen
                gameObject.transform.Translate(Vector2.right * speedX * Time.deltaTime);
                //quay dau
                if(gameObject.transform.localScale.x <0)
                {
                    gameObject.transform.localScale = new Vector2(
                        gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y
                       
                    );
                }
            }
            else if(Input.GetKey(KeyCode.Space))//nhay cao
            {
                //thiet lap trang thai
                player.SetBool("isRunning",true);
                player.SetBool("isIdle",false);
                //if(gameObject.tag == "Brick")
                //{
                    gameObject.GetComponent<Rigidbody2D>().velocity
                = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,
                speedY);
                //}
                
            }
            else
            {
                if(isBtnUpClick==true || isBtnRightClick==true || isBtnLeftClick==true) //if (Input.GetMouseButtonDown(0))
                {
                    player.SetBool("isRunning",true);
                    player.SetBool("isIdle",false);
                    //idle=IdleActive();
                    //StartCoroutine(idle);     
                }
                else
                {
                    player.SetBool("isRunning",false);
                    player.SetBool("isIdle",true);
                }
                
            }
            
           
        }
    }

    private void OnCollisionEnter2D(Collision2D other) {
        if(other.gameObject.tag == "Coin")
        {
            score +=1;
            Destroy(other.gameObject);
            txtDiem.text = "Score: "+score.ToString();
            //goi hieu ung
            GameObject gob = Instantiate(hieuUng,gameObject.transform.position,Quaternion.identity);
            Destroy(gob,3);
        }
        if(other.gameObject.tag == "CNV")
        {
            score -=2;
            Destroy(other.gameObject);
            txtDiem.text = "Score: "+score.ToString();
            //goi hieu ung
            GameObject gob = Instantiate(hieuUng1,gameObject.transform.position,Quaternion.identity);
            Destroy(gob,2);
            if(score <=0)
            {
                //Application.LoadLevel("Menu");
            }
        }
    }
}
