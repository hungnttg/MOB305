﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    private Transform p;
    void Start()
    {
        //anh xa doi tuong game
        p= GameObject.Find("player_ani").transform;
    }

    void Update()
    {
        //update vi tri camera
        if(p!=null)
        {
            Vector3 vitrimoi = transform.position;
            vitrimoi.x = p.position.x;
            transform.position = vitrimoi;
        }
    }
}
