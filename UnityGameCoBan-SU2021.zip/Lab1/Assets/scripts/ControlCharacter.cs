﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlCharacter : MonoBehaviour
{
    //Khai báo các biến sử dụng
    public static bool isGameOver = false;//trang thai ket thuc game
    public float jumpHeigh, speed;//toc do chay, nhay
    private Animator player;
    int score=0;
    public Text txtScore;
    public GameObject particleSystem;
    void Start()
    {
         //findByViewId->anh xa id tu thiet ke sang code
        player = GetComponent<Animator>();
        Time.timeScale=1;//ti le voi thoi gian thuc
        isGameOver=false;
        txtScore = GameObject.Find("txtTextScore").GetComponent<Text>();
    }
    //ham detech va cham
    void OnCollisionEnter2D(Collision2D other) {
        if(other.gameObject.tag=="Tien")
        {
            score+=1;
            Destroy(other.gameObject);//huy coin
            txtScore.text = "Score: "+score.ToString();
            //xu ly hieu ung
            GameObject g = Instantiate(particleSystem,gameObject.transform.position,Quaternion.identity);//tao particle system
            Destroy(g,3);//huy sau thoi gian 3s
        }
        if(other.gameObject.tag=="CNV1")
        {
            score -=1;//tru diem
            Destroy(other.gameObject);//huy doi tuong
            txtScore.text = "Score: "+score.ToString();
            if(score<=0)
            {
                Application.LoadLevel("Menu");
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
       if(!isGameOver)//neu game chua ket thuc
       {
           if(Input.GetKey(KeyCode.LeftArrow))//khi nguoi dung nhan Left
           {
               player.SetBool("isRunning",true);//chay-> true
               player.SetBool("isIdle",false);//dung yen->false
               gameObject.transform.Translate(Vector3.left * speed * Time.deltaTime);//di chuyen
               //quay dau
               if(gameObject.transform.localScale.x > 0)
               {
                   gameObject.transform.localScale = new
                   Vector3(gameObject.transform.localScale.x * -1,
                   gameObject.transform.localScale.y,
                   gameObject.transform.localScale.z);
               }
           }
           else if(Input.GetKey(KeyCode.RightArrow))//khi nguoi dung nhan righ
            {
               player.SetBool("isRunning",true);//chay-> true
               player.SetBool("isIdle",false);//dung yen->false
               gameObject.transform.Translate(Vector3.right * speed * Time.deltaTime);//di chuyen
            //quay dau
               if(gameObject.transform.localScale.x < 0)
               {
                   gameObject.transform.localScale = new
                   Vector3(gameObject.transform.localScale.x * -1,
                   gameObject.transform.localScale.y,
                   gameObject.transform.localScale.z);
               }           
            }
            else if(Input.GetKey(KeyCode.Space))//nhay cao
            {
                gameObject.GetComponent<Rigidbody2D>().velocity
                = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,jumpHeigh);
            }
            else//neu khong nhan phim nao
            {
                player.SetBool("isRunning",false);//chay-> false
               player.SetBool("isIdle",true);//dung yen->true
            }
       }
    }
}
