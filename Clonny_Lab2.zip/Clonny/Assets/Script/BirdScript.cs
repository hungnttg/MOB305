﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdScript : MonoBehaviour
{
    //khai bao van toc nhay
    public float jumpVelocity;
    float g = -9.8f;//gia toc
    void Start()
    {
        
    }
    void Update()
    {
        //vitri y += v0 * t + g * t*t/2
        transform.position += Vector3.up *(jumpVelocity*Time.deltaTime + g * Time.deltaTime * Time.deltaTime/2);
        jumpVelocity += g*Time.deltaTime;
        //xu ly su kien nhan chuot trai hoac nhan dau cach
        if(Input.GetKeyDown(KeyCode.Space)|| Input.GetMouseButtonDown(0))
        {
            jumpVelocity = 3f;
        }

    }
}
