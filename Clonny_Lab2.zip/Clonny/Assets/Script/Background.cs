﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
  //khai baos van toc
    public float speed;
//khai bao so luong background
    public int numOfBG=6;
    void Start()
    {
        
    }

    void Update()
    {
        //background di chuyen
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }
    //ham detect va cham voi BGLooper
     void OnTriggerEnter2D(Collider2D other) {
        if(other.name =="BGLooper")//neu va cham voi BGLooper
        {
            //tinh toan do rong cua 1 background
            float widthOfOneBG = ((BoxCollider2D)GetComponent<Collider2D>()).size.x-0.01f;
            //hoan vi cac background
            Vector3 pos = this.transform.position;//lay vi tri hien thoi
            pos.x += widthOfOneBG*numOfBG;//vi tri x + do dai cua toan bo background
            this.transform.position = pos;//chuyen den vi tri moi
        }
    }
}
